package Model;


import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author costa
 */
@Entity
@Table(name="CORD_ESTAG")
public class Coordenador implements Serializable {
  @Id  
  @Column(name="IDCORD_ESTAG")  
  private int idCordEstagio;
  @Column(name="ENDERECO")
  private String endereco;

  @Column(name="NOME")
  private String nome;
  @Column(name="CPF")
  private int cpf ;
  @Column(name="RG")
  private String rg;
  @Column(name="MATRICULA")
  private int matricula;
  @Column(name="EMAIL")
  private String email;
  @Column(name="TEL")
  private int tel;

    public int getIdCordEstagio() {
        return idCordEstagio;
    }

    public void setIdCordEstagio(int idCordEstagio) {
        this.idCordEstagio = idCordEstagio;
    }

   
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }
    
    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
 
}
