package Model;


import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author costa
 */
@Entity
@Table (name="EMPRESA")
public class Empresa implements Serializable {
  @Id  
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name="IDEMPRESA")  
  private int idEmpresa;
  @Column(name="ENDERECO")
  private String endereco;
  @Column(name="NOME")
  private String nome;
  @Column(name="CNPJ")
  private int cnpj;
  @Column(name="RAMO")
  private String ramo;
  @Column(name="EMAIL")
  private String email;
  @Column(name="TEL")
  private String tel;
    public int getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(int idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

     public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCnpj() {
        return cnpj;
    }

    public void setCnpj(int cnpj) {
        this.cnpj = cnpj;
    }

    public String getRamo() {
        return ramo;
    }

    public void setRamo(String ramo) {
        this.ramo = ramo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }
 
}
