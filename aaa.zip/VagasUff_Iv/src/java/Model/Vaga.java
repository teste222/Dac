/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author costa
 */
@Entity
@Table (name="VAGA")
public class Vaga implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @Column(name="IDEMPRESA")
    private int idEmpresa;
    @Column(name="STATUS")
    private boolean status;
    @Column(name="NOME")
    private String nome;
    @Column(name="DESCRICAO")
    private String descricao;
    @Column(name="DATALIMITE")
    private String datalimite;
    @Column(name="XORPCD")
    private boolean xorpcd;
    @Column(name="IDIOMA")
    private String idioma;
    @Column(name="CIDADE")
    private String cidade;

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(int idEmpresa) {
        this.idEmpresa = idEmpresa;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDatalimite() {
        return datalimite;
    }

    public void setDatalimite(String datalimite) {
        this.datalimite = datalimite;
    }

    public boolean isXorpcd() {
        return xorpcd;
    }

    public void setXorpcd(boolean xorpcd) {
        this.xorpcd = xorpcd;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }
    
    
}
