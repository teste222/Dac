/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 *
 * @author Paulo
 */

@Entity
@Table (name="CANDIDATURA")
public class Candidatura implements Serializable {
   
  @Id  
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name="ID")  
   private int id;
  
  @Column(name="IDALUNO")
   private int idaluno;
  
  @Column(name="IDVAGA")
   private int idvaga;
  
  @Column(name="DATA")
   private String data;
  
  @Column(name="APROVADA")
  private char aprovada;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdaluno() {
        return idaluno;
    }

    public void setIdaluno(int idaluno) {
        this.idaluno = idaluno;
    }

    public int getIdvaga() {
        return idvaga;
    }

    public void setIdvaga(int idvaga) {
        this.idvaga = idvaga;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public char getAprovada() {
        return aprovada;
    }

    public void setAprovada(char aprovada) {
        this.aprovada = aprovada;
    }
  
}
