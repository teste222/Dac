/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Curso;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author costa
 */
public class CursoDao {
    public void addCurso(int idAluno, String tipo,String nome, String instituicao, String inicio, String fim){
        Session session = HibernateSessionFactory.getSession();
        
        Curso curso = new Curso();
        
        session.getTransaction().begin();
        
        String name = nome;
        
        name = name.toLowerCase();
        
        curso.setIdAluno(idAluno);
        curso.setTipo(tipo);
        curso.setNome(name);
        curso.setInstituicao(instituicao);
        curso.setInicio(inicio);
        curso.setFim(fim);
        
        session.save(curso);
        
        session.getTransaction().commit();
        session.close();
    }

    public void removeCurso(String curso, int idAluno) {
        
        Session session = HibernateSessionFactory.getSession();
        session.getTransaction().begin();

        Query query = session.createSQLQuery("DELETE FROM CURSO WHERE NOME= :curso AND IDALUNO= :idAluno");
        query.setString("curso", curso);
        query.setInteger("idAluno", idAluno);

        int result = query.executeUpdate();

        session.getTransaction().commit();
        session.close();
    }
        
        
    
}
