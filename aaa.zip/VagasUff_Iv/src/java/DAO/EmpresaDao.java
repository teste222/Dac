/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Empresa;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author costa
 */
public class EmpresaDao {
    
    public Empresa getEmpresa(int cnpj){
        Session session = HibernateSessionFactory.getSession();
        Empresa empresa = null;
        
        Query query = session.createSQLQuery("SELECT * FROM EMPRESA WHERE CNPJ = :cnpj").addEntity(Empresa.class);
        query.setInteger("cnpj", cnpj);
        
        List emps= query.list();
       
        if (!emps.isEmpty()) { //se a lista não for vazia da um new Empresa
            empresa = new Empresa();
            Iterator iterator = emps.iterator();
            if (iterator.hasNext()) {
                empresa = (Empresa) iterator.next();
            }
        }
        
        session.close();
        return empresa;
    }
    
    
}
