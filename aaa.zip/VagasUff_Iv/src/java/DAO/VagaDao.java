/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Aluno;
import Model.Vaga;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author costa
 */
public class VagaDao {
    
    public Vaga getVagaById(int idVaga){
        Session session = HibernateSessionFactory.getSession();
        
        Vaga vaga = new Vaga();
        
        Query query = session.createSQLQuery("SELECT * FROM VAGA WHERE ID = :idvaga").addEntity(Vaga.class);
        query.setInteger("idvaga", idVaga);
        
        List vagas = query.list();
        
        if (!vagas.isEmpty()) { //se a lista não for vazia da um new vaga
            vaga = new Vaga();
            Iterator iterator = vagas.iterator();
            if (iterator.hasNext()) {
                vaga = (Vaga) iterator.next();
            }
        }
        
        return vaga;
    }
    
   public List<Vaga> vagasRecomendadasSemPcd(Aluno aluno){ //VAGAS PARA NÃO DEFICIENTES
        Session session = HibernateSessionFactory.getSession();
        
        int idAluno = aluno.getIdAluno();
        
        Query query = session.createSQLQuery("SELECT * FROM VAGA, ALUNO, IDIOMA WHERE VAGA.STATUS= :true AND"
         + " ALUNO.ID= :alunoId AND ALUNO.ID= IDIOMA.IDALUNO AND VAGA.XORPCD= :false AND(VAGA.IDIOMA= IDIOMA.LINGUA OR ALUNO.ENDERECO = VAGA.CIDADE)" ).addEntity(Vaga.class);
        query.setBoolean("true", true);
        query.setBoolean("false", false);
        query.setInteger("alunoId", idAluno);
        
        List vagas = query.list();
        
        List<Vaga> vagasSemDuplicacao = new ArrayList<>(new LinkedHashSet<>(vagas)); //HASHSET RETIRA AS CÓPIAS
        
        return vagasSemDuplicacao;        
    }
    
    public List<Vaga> vagasRecomendadasXORPCD(Aluno aluno){ //VAGAS EXCLUSIVAS PARA DEFICIENTES
        Session session = HibernateSessionFactory.getSession();
        
        int idAluno = aluno.getIdAluno();
        
        Query query = session.createSQLQuery("SELECT * FROM VAGA, ALUNO, IDIOMA WHERE VAGA.STATUS= :true AND"
         + " ALUNO.ID= :alunoId AND ((ALUNO.ID= IDIOMA.IDALUNO AND VAGA.IDIOMA= IDIOMA.LINGUA) OR VAGA.XORPCD= :true OR ALUNO.ENDERECO = VAGA.CIDADE)" ).addEntity(Vaga.class);
        query.setBoolean("true", true);
        query.setInteger("alunoId", idAluno);
        
        
        List vagas = query.list();
        
        List<Vaga> vagasSemDuplicacao =
        new ArrayList<>(new LinkedHashSet<>(vagas)); //HASHSET RETIRA AS CÓPIAS
        
        return vagasSemDuplicacao;        
    }
    
     public List<Vaga> vagasPorEmpresa(int idEmpresa){ //VAGAS EXCLUSIVAS PARA DEFICIENTES
        Session session = HibernateSessionFactory.getSession();
               
        Query query = session.createSQLQuery("SELECT * FROM VAGA WHERE VAGA.IDEMPRESA = :idEmpresa" ).addEntity(Vaga.class);
        query.setInteger("idEmpresa", idEmpresa);
            
        List vagas = query.list();
        
        return vagas;        
    }
     
        public List<Vaga> vagasDisponiveisSemPcd(Aluno aluno){ //VAGAS normais
        Session session = HibernateSessionFactory.getSession();
        
        int idAluno = aluno.getIdAluno();
        
        Query query = session.createSQLQuery("SELECT * FROM VAGA, ALUNO WHERE VAGA.STATUS= :true AND"
         + " ALUNO.ID= :alunoId AND VAGA.XORPCD= :false" ).addEntity(Vaga.class);
        query.setBoolean("true", true);
        query.setBoolean("false", false);
        query.setInteger("alunoId", idAluno);
        
        
        List vagas = query.list();
        
        List<Vaga> vagasSemDuplicacao =
        new ArrayList<>(new LinkedHashSet<>(vagas)); //HASHSET RETIRA AS CÓPIAS
        
        return vagasSemDuplicacao;        
    }

    
    public List<Vaga> vagasDisponiveisXORPcd(Aluno aluno){ //VAGAS EXCLUSIVAS PARA DEFICIENTES
        Session session = HibernateSessionFactory.getSession();
        
        int idAluno = aluno.getIdAluno();
        
        Query query = session.createSQLQuery("SELECT * FROM VAGA, ALUNO WHERE VAGA.STATUS= :true AND"
         + " ALUNO.ID= :alunoId " ).addEntity(Vaga.class);
        query.setBoolean("true", true);
        query.setInteger("alunoId", idAluno);
        
        
        List vagas = query.list();
        
        List<Vaga> vagasSemDuplicacao =
        new ArrayList<>(new LinkedHashSet<>(vagas)); //HASHSET RETIRA AS CÓPIAS
        
        return vagasSemDuplicacao;        
    }
    
}
