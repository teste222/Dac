/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Usuario;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author costa
 */
public class UsuarioDao {
    
    public Usuario getUsuario(int login, String senha) {
        Session session = HibernateSessionFactory.getSession();
        Usuario usuario = null;

        Query query = session.createSQLQuery("SELECT * FROM USUARIO WHERE LOGIN = :login AND SENHA = :senha").addEntity(Usuario.class);
        query.setInteger("login", login);
        query.setString("senha", senha);

        List users = query.list();

        if (!users.isEmpty()) { //se houver um usuario
            usuario = new Usuario();
            Iterator iterator = users.iterator();
            if (iterator.hasNext()) {
                usuario = (Usuario) iterator.next();
            }
        }
        return usuario;
    }
}
