/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Idioma;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author costa
 */
public class IdiomaDao {
    
    public void addIdioma(int idAluno, String lingua, String escrita, String leitura, String conversacao) {
        Session session = HibernateSessionFactory.getSession();

        Idioma idioma = new Idioma();

        String idio = lingua;
        idio = idio.toLowerCase();
        
        session.getTransaction().begin();
        
        idioma.setIdAluno(idAluno);
        idioma.setLingua(idio);
        idioma.setEscrita(escrita);
        idioma.setLeitura(leitura);
        idioma.setConversacao(conversacao);

        session.save(idioma);

        session.getTransaction().commit();
        session.close();

    }

    public void removeIdioma(String idioma, int idAluno) {
        Session session = HibernateSessionFactory.getSession();
        session.getTransaction().begin();

        Query query = session.createSQLQuery("DELETE FROM IDIOMA WHERE LINGUA= :idioma AND IDALUNO= :idAluno");
        query.setString("idioma", idioma);
        query.setInteger("idAluno", idAluno);

        int result = query.executeUpdate();

        session.getTransaction().commit();
        session.close();
    }
    
}
