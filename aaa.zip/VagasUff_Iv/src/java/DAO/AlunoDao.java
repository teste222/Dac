/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Aluno;
import Model.Curso;
import Model.Idioma;
import Model.Usuario;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author costa
 */
public class AlunoDao {
    public Aluno getAlunoMatricula(int matricula) { //RETORNA UM ALUNO passando a matricula
        Session session = HibernateSessionFactory.getSession();
        Aluno aluno = null;
        
        Query query = session.createSQLQuery("SELECT * FROM ALUNO WHERE MATRICULA = :matricula").addEntity(Aluno.class);
        query.setInteger("matricula", matricula);
       
        List alunos = query.list();
       
        if (!alunos.isEmpty()) { //se a lista não for vazia da um new aluno
            aluno = new Aluno();
            Iterator iterator = alunos.iterator();
            if (iterator.hasNext()) {
                aluno = (Aluno) iterator.next();
            }
        }
        return aluno;
    } //RETORNA UM ALUNO
    
    public Aluno getAlunoById(int alunoId) { //RETORNA UM ALUNO passando a matricula
        Session session = HibernateSessionFactory.getSession();
        Aluno aluno = null;
        
        Query query = session.createSQLQuery("SELECT * FROM ALUNO WHERE ID = :alunoId").addEntity(Aluno.class);
        query.setInteger("alunoId", alunoId);
       
        List alunos = query.list();
       
        if (!alunos.isEmpty()) { //se a lista não for vazia da um new aluno
            aluno = new Aluno();
            Iterator iterator = alunos.iterator();
            if (iterator.hasNext()) {
                aluno = (Aluno) iterator.next();
            }
        }
        return aluno;
    } //RETORNA UM ALUNO passando o id artificial
    
    
    public void updateAluno(int mat, String nome, String end, String nasc, String email, int tel, String civil, String deficiencia) { //ATUALIZA DADOS DO ALUNO
        Session session = HibernateSessionFactory.getSession();
        Aluno aluno = new Aluno();
        
        String ende = end;
        ende = ende.toLowerCase();

        session.getTransaction().begin();
        
        Query query = session.createSQLQuery(        
            "UPDATE ALUNO SET ENDERECO= :end, NOME= :nome, NASCIMENTO= :nasc, EMAIL= :email, TEL= :tel, EST_CIVIL= :civil, DEFICIENCIA= :deficiencia WHERE MATRICULA = :matricula");
        query.setInteger("matricula", mat);
        query.setString("nome", nome);
        query.setString("end", ende);
        query.setString("nasc", nasc);
        query.setString("email", email);
        query.setInteger("tel", tel);
        query.setString("civil", civil);
        query.setString("deficiencia", deficiencia);
        
        int result = query.executeUpdate();

        session.getTransaction().commit();
        session.close();

    } //ATUALIZA DADOS DO ALUNO
    
    
    public void updateAlunoSenha(int login, String senha){ //ALTERA SENHA DO ALUNO
        Session session = HibernateSessionFactory.getSession();
        Usuario usuario = new Usuario();
        
        session.getTransaction().begin();
        
        Query query = session.createSQLQuery(        
            "UPDATE USUARIO SET SENHA= :senha WHERE LOGIN= :login");
        query.setInteger("login", login);
        query.setString("senha", senha);
        
        int result = query.executeUpdate();

        session.getTransaction().commit();
        session.close();        
    } //ALTERA SENHA DO ALUNO
    
    public List<Idioma> exibeIdiomas(int idAluno) { //RETORNA TODOS OD IDIOMAS DE UM ALUNO PASSANDO O ID AUTOMATICO DO ALUNO
        Session session = HibernateSessionFactory.getSession();
        
        Query query = session.createSQLQuery("SELECT * FROM IDIOMA WHERE IDALUNO = :idAluno").addEntity(Idioma.class);
        query.setInteger("idAluno", idAluno);
       
        List<Idioma> idiomas = query.list();
        
        session.close();
      
        return idiomas;
    } //RETORNA TODOS OS IDIOMAS DE UM ALUNO PASSANDO O ID AUTOMATICO DO ALUNO
    
    public List<Curso> exibeCursos(int idAluno) { //RETORNA TODOS OS CURSOS DE UM ALUNO PASSANDO O ID AUTOMATICO DO ALUNO
        Session session = HibernateSessionFactory.getSession();
        
        Query query = session.createSQLQuery("SELECT * FROM CURSO WHERE IDALUNO = :idAluno").addEntity(Curso.class);
        query.setInteger("idAluno", idAluno);

        List<Curso> cursos = query.list();

        session.close();

        return cursos;
    } //RETORNA TODOS OS CURSOS DE UM ALUNO PASSANDO O ID AUTOMATICO DO ALUNO

    public List<Aluno> exibeAlunosHabilitar() { //RETORNA TODOS OS ALUNOS
        Session session = HibernateSessionFactory.getSession();

        Query query = session.createSQLQuery("SELECT * FROM ALUNO WHERE APTO = :false").addEntity(Aluno.class);
        query.setBoolean("false", false);

        List<Aluno> alunos = query.list();

        session.close();

        return alunos;
    } //RETORNA TODOS OS ALUNOS COM APTU = FALSE

    public void habilitaAluno(int idAluno) { //ALTERA SENHA DO ALUNO
        Session session = HibernateSessionFactory.getSession();
        Aluno aluno = new Aluno();

        session.getTransaction().begin();

        Query query = session.createSQLQuery(
                "UPDATE ALUNO SET APTO= :true WHERE ID= :idAluno");
        query.setBoolean("true", true);
        query.setInteger("idAluno", idAluno);

        int result = query.executeUpdate();

        session.getTransaction().commit();
        session.close();
    } //SETA ALUNO COMO APTO
}
