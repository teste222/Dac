/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Aluno;
import Model.Curso;
import Model.Candidatura;
import Model.Vaga;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Paulo
 */
public class CandidaturaDAO {
    
    public List<Aluno> exibeCandidatos(int idVaga) { 
        Session session = HibernateSessionFactory.getSession();
        
        Query query = session.createSQLQuery("SELECT * FROM ALUNO, CANDIDATURA"
                + " WHERE CANDIDATURA.IDVAGA = :idVaga AND ALUNO.ID = CANDIDATURA.IDALUNO ").addEntity(Aluno.class);

       query.setInteger("idVaga", idVaga);     
        List<Aluno> alunos = query.list();
        
        session.close();      
        return alunos;
    }
    
        public List<Candidatura> getCandidaturaVaga(int idVaga) { 
        Session session = HibernateSessionFactory.getSession();
        
        Query query = session.createSQLQuery("SELECT * FROM ALUNO, CANDIDATURA"
                + " WHERE CANDIDATURA.IDVAGA = :idVaga ").addEntity(Candidatura.class);

       query.setInteger("idCandidatura", idVaga);     
        List<Candidatura> candidaturas = query.list();
        
        session.close();      
        return candidaturas;
    }
    
     public List<Vaga> exibeVagaPValidar() { //RETORNA TODAS AS VAGAS COM APROVADA = 1
        Session session = HibernateSessionFactory.getSession();

        Query query = session.createSQLQuery("SELECT * FROM VAGA,CANDIDATURA WHERE CANDIDATURA.APROVADA = :um AND VAGA.ID = CANDIDATURA.IDVAGA").addEntity(Vaga.class);
        query.setString("um", "1");

        List<Vaga> vagas = query.list();

        session.close();
        return vagas;
    } //RETORNA TODOS OS ALUNOS COM APTO = FALSE  
    
    public List<Aluno> exibeAlunosPValidar() { //RETORNA TODAS AS VAGAS COM APROVADA = 1
        Session session = HibernateSessionFactory.getSession();

        Query query = session.createSQLQuery("SELECT * FROM ALUNO,CANDIDATURA WHERE CANDIDATURA.APROVADA = :um AND ALUNO.ID = CANDIDATURA.IDALUNO").addEntity(Aluno.class);
        query.setString("um", "1");

        List<Aluno> alunos = query.list();

        session.close();

        return alunos;
    } //RETORNA TODOS OS ALUNOS COM APTO = FALSE  
    
    
    public void validaAluno(int idAluno, int idVaga) { //ALTERA APROVADA
        Session session = HibernateSessionFactory.getSession();
        Candidatura candidatura = new Candidatura();

        session.getTransaction().begin();

        Query query = session.createSQLQuery(
                "UPDATE CANDIDATURA SET APROVADA= :dois WHERE IDALUNO= :idAluno AND IDVAGA= :idVaga");
        query.setString("dois","2");

        int result = query.executeUpdate();

        session.getTransaction().commit();
        session.close();
    } //SETA APROVADA COMO 2    
   
        public void selecionaAluno(int idAluno, int idVaga) { //ALTERA APROVADA
        Session session = HibernateSessionFactory.getSession();
        Candidatura candidatura = new Candidatura();

        session.getTransaction().begin();

        Query query = session.createSQLQuery(
                "UPDATE CANDIDATURA SET APROVADA= :um WHERE IDALUNO= :idAluno AND IDVAGA= :idVaga");
        query.setString("um","1");

        int result = query.executeUpdate();

        session.getTransaction().commit();
        session.close();
    } //SETA APROVADA COMO 1
    
        public List<Candidatura> getCandidaturasAluno(int idAluno) { 
        Session session = HibernateSessionFactory.getSession();
        
        Query query = session.createSQLQuery("SELECT * FROM CANDIDATURA"
                + " WHERE CANDIDATURA.IDALUNO = :idAluno ").addEntity(Candidatura.class);

       query.setInteger("idAluno", idAluno);     
        List<Candidatura> candidaturas = query.list();
        
        session.close();      
        return candidaturas;
    }
        
        
}
