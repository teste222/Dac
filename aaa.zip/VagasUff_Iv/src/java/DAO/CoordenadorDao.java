/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Model.Aluno;
import Model.Coordenador;
import Model.Empresa;
import Model.Usuario;
import java.util.Iterator;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author costa
 */
public class CoordenadorDao {
    
     public Coordenador getCoordenador(int matricula) { //pega um coordenador passando a matricula
        Session session = HibernateSessionFactory.getSession();
        Coordenador coord = null;
        
        Query query = session.createSQLQuery("SELECT * FROM CORD_ESTAG WHERE MATRICULA = :matricula").addEntity(Coordenador.class);
        query.setInteger("matricula", matricula);
       
        List coords= query.list();
       
        if (!coords.isEmpty()) { //se a lista não for vazia da um new Coordenador
            coord = new Coordenador();
            Iterator iterator = coords.iterator();
            if (iterator.hasNext()) {
                coord = (Coordenador) iterator.next();
            }
        }
        
        session.close();
        return coord;
    } 
    
     public void addAluno(int mat, int cpf){ //cria um novo usuario com senha e um novo aluno com matricula
         Session session = HibernateSessionFactory.getSession();
         
         Aluno aluno = new Aluno();
         Usuario usuario = new Usuario();
         
         session.getTransaction().begin();
         
         aluno.setMatricula(mat);
         aluno.setCpf(cpf);
         
         usuario.setLogin(mat);
         usuario.setSenha("Inicial");
         
         session.save(aluno);
         session.save(usuario);
 
         session.getTransaction().commit();
         session.close();
     }
     
    public void addEmpresa(int cnpj, String nome) {
        Session session = HibernateSessionFactory.getSession();

        Empresa empresa = new Empresa();
        Usuario usuario = new Usuario();

        session.getTransaction().begin();

        empresa.setCnpj(cnpj);
        empresa.setNome(nome);

        usuario.setLogin(cnpj);
        usuario.setSenha("Inicial");

        session.save(empresa);
        session.save(usuario);

        session.getTransaction().commit();
        session.close();
    }
     
}
