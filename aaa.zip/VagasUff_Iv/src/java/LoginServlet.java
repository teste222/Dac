/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import DAO.AlunoDao;
import DAO.CoordenadorDao;
import DAO.EmpresaDao;
import DAO.UsuarioDao;
import Model.Aluno;
import Model.Coordenador;
import Model.Empresa;
import Model.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author costa
 */
@WebServlet(urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          response.setContentType("text/html;charset=UTF-8");
          
          Aluno aluno = null;
          Coordenador coord = null;
          Empresa empresa = null;
          Usuario usuario = null;
          UsuarioDao usuarioDao = new UsuarioDao();
          String telaJsp;   //String pra passar o nome do jsp
          
          int login = Integer.parseInt(request.getParameter("login")); //numero de login do usuário
          String senha = request.getParameter("senha"); //pegando numero da senha
          
          usuario = usuarioDao.getUsuario(login, senha); //verifica se há usuario
          
          if (usuario != null) { //se houver um usuario

              switch (Integer.parseInt(request.getParameter("tipo"))) {
                  case 1: //aluno

                      AlunoDao alunoDao = new AlunoDao();
                      aluno = (Aluno) alunoDao.getAlunoMatricula(login);

                      if (aluno != null) {
                          request.setAttribute("usuario", usuario);
                          request.setAttribute("aluno", aluno);
                          telaJsp = "homeAluno.jsp"; //tela com t maiusculo
                      } else {
                          telaJsp = "user404.jsp";
                      }
                      break;
                  case 2:

                      CoordenadorDao coordDao = new CoordenadorDao();
                      coord = (Coordenador) coordDao.getCoordenador(login);

                      if (coord != null) {
                          request.setAttribute("usuario", usuario);
                          request.setAttribute("coordenador", coord);
                          telaJsp = "homeCoordenador.jsp";
                      } else {
                          telaJsp = "user404.jsp";
                      }
                      break;
                  case 3:
                      
                      EmpresaDao empDao = new EmpresaDao();
                      empresa = (Empresa) empDao.getEmpresa(login);

                      if (empresa != null) {
                          request.setAttribute("usuario", usuario);
                          request.setAttribute("empresa", empresa);
                          telaJsp = telaJsp = "homeEmpresa.jsp";
                      } else {
                          telaJsp = "user404.jsp";
                      }
                      break;
                  default:
                      telaJsp = "user404.jsp";
                      break;
              }
          }else{ 
              telaJsp ="user404.jsp";
          }
        
        RequestDispatcher view
                    = request.getRequestDispatcher(telaJsp); //string da tela jsp que vai ser chamada
            view.forward(request, response);
          
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
